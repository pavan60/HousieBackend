package com.pavan.BackendHousie.Housie.Entity;

public class Samp {
    private String name;
    Samp(){
    }
    Samp(String name){
        this.name = name;
    }
}
