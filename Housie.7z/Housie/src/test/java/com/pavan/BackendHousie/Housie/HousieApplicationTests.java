package com.pavan.BackendHousie.Housie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HousieApplicationTests {

	@Test
	void contextLoads() {
	}

}
